from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
import razorpay
from razorpay_keys import RAZORPAY_KEY_ID, RAZORPAY_SECRET_ID

app = Flask(__name__)
app.secret_key = "49494asdklfjasdklflaksdf"   

# Database connection setup
def get_db_connection():
    conn = mysql.connector.connect(
        host='localhost',
        user='root',
        password='Cdac@2022',
        database='electricity_billing'
    )
    return conn

# Splash Screen Route
@app.route('/')
def splash():
    return render_template('splash.html')

# Registration Route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO login (UserName, Password) VALUES (%s, %s)', (username, password))
        conn.commit()
        conn.close()
        flash('Registration successful! Please log in.')
        return redirect(url_for('login'))
    return render_template('register.html')

# Login Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM login WHERE UserName=%s AND Password=%s', (username, password))
        user = cursor.fetchone()
        conn.close()
        if user:
            session['username'] = username
            return redirect(url_for('main_system'))
        else:
            flash('Invalid login credentials')
    return render_template('login.html')


# Main System Route
@app.route('/main_system')
def main_system():
    if 'username' in session:
        return render_template('main_system.html')
    else:
        return redirect(url_for('login'))

# Add Customer Route
@app.route('/add_customer', methods=['GET', 'POST'])
def add_customer():
    if request.method == 'POST':
        name = request.form['name']
        meter_number = request.form['meter_number']
        address = request.form['address']
        state = request.form['state']
        city = request.form['city']
        email = request.form['email']
        phone = request.form['phone']
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO emp (Name, MeterNumber, Address, State, City, Email, Phone) VALUES (%s, %s, %s, %s, %s, %s, %s)', 
                       (name, meter_number, address, state, city, email, phone))
        conn.commit()
        conn.close()
        flash('Customer added successfully')
        return redirect(url_for('main_system'))
    return render_template('add_customer.html')

# Generate Bill Route
@app.route('/generate_bill', methods=['GET', 'POST'])
def generate_bill():
    if request.method == 'POST':
        meter_number = request.form['meter_number']
        units = request.form['units']
        month = request.form['month']
        amount = float(units) * 5.0  # Assuming a rate of 5 per unit for simplicity
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO bill (MeterNumber, Units, Month, Amount) VALUES (%s, %s, %s, %s)', 
                       (meter_number, units, month, amount))
        conn.commit()
        conn.close()
        flash('Bill generated successfully')
        return redirect(url_for('main_system'))
    return render_template('generate_bill.html')

# Pay Bill Route
@app.route('/pay_bill', methods=['GET', 'POST'])
def pay_bill():
    if request.method == 'POST':
        meter_number = request.form['meter_number']
        amount = request.form['amount']
        client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_SECRET_ID))
        payment = client.order.create({'amount': int(float(amount) * 100), 'currency': 'INR', 'payment_capture': '1'})
        return render_template('pay_bill.html', payment=payment, RAZORPAY_KEY_ID=RAZORPAY_KEY_ID)
    return render_template('pay_bill_form.html') #, payment=None, RAZORPAY_KEY_ID=RAZORPAY_KEY_ID)

# Payment Success Route
@app.route('/payment_success', methods=['POST'])
def payment_success():
    return "Payment was successful!"

# Show Details Route
@app.route('/show_details')
def show_details():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM emp')
    customers = cursor.fetchall()
    cursor.execute('SELECT * FROM bill')
    bills = cursor.fetchall()
    conn.close()
    return render_template('show_details.html', customers=customers, bills=bills)

if __name__ == '__main__':
    app.run(debug=True)
